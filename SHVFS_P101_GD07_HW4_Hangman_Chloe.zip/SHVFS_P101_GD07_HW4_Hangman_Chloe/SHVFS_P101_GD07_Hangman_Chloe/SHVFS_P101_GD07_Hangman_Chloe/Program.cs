﻿using System;
using System.Collections.Generic;

namespace SHVFS_P101_GD07_Hangman_Chloe
{
    class Program
    {
        public static string rightword;
        public static char[] wordToGuess;
        public static int wrongTry = 0;
        public static bool won = false;
        public static char guess;
        public static int letterNum = 0;
        public static Dictionary<int, string> wordlist = new Dictionary<int, string>();

        static void Main(string[] args)
        {
            var title = "Hangman";
            Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(title);
            Console.CursorTop = 1;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Please press any key to start the game!");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.CursorTop = 2;
            Console.WriteLine("ATTENTION:You only have six lives!");
            Console.ReadKey();
            Console.Clear();

            
            wordlist.Add(1, "black");
            wordlist.Add(2, "blue");
            wordlist.Add(3, "yellow");
            wordlist.Add(4, "orange");
            wordlist.Add(5, "green");
            wordlist.Add(6, "purple");
            wordlist.Add(7, "white");
            wordlist.Add(8, "gray");

            Random ram = new Random();
            int randomNumber = ram.Next(1, wordlist.Keys.Count); //获取字典长度
            rightword = wordlist[randomNumber];
            //rightword =  "bcack";
            wordToGuess = new char[rightword.Length];

            DrawShelf();
            
            //画线——
            for(int i = 0; i < wordToGuess.Length; i++)
            {
                wordToGuess[i] = '_';
            }
            while (true)
            {
                for (int i = 0; i < wordToGuess.Length; i++)
                {
                    Console.Write(wordToGuess[i]);
                }
                break;
            }
            //

            Console.WriteLine("\nGuess A letter to spell the COLOR:");
            while (won!=true)
            {
                Console.CursorTop = 10;
                Console.CursorLeft = 0;
                guess = char.Parse(Console.ReadLine());
                guess = char.Parse(guess.ToString().ToLower()); //.ToLower()输入大写转小写

                //if(guess.ToString().Length > 1)
                //{
                //    Console.WriteLine("You can only press one word!");
                //    Console.ReadKey();
                //    RestartGame();
                //}
                

                if (rightword.Contains(guess))
                {
                    for (int i = 0; i < rightword.Length; i++)
                    {
                        if (rightword[i] == guess)
                        {
                            wordToGuess[i] = guess;
                            letterNum++;
                        }
                        if (letterNum == wordToGuess.Length)
                        {
                            won = true;                           
                        }
                    }
                    for (int j = 0; j < wordToGuess.Length; j++)
                    {
                        //Console.WriteLine(wordToGuess.Length);
                        Console.CursorTop = 8;
                        Console.Write(wordToGuess[j]);
                    }
                }
                else
                {
                    wrongTry++;
                    DrawHangman(wrongTry);
                    if (wrongTry > 5)
                    {
                        Console.CursorTop = 12;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("The hangman is dead.");
                        Console.WriteLine("Press ENTER to restart the game.");
                        var continueKey = Console.ReadKey(true);
                        if (continueKey.Key == ConsoleKey.Enter)
                        {
                            RestartGame();
                        }
                        else
                        {
                            Console.WriteLine("OKAY!!!Press any key you like~");
                            Console.ReadKey();
                            RestartGame();
                        }
                        //Console.ReadLine();
                    }
                }
                if (won == true)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.CursorTop = 12;
                    Console.WriteLine("\nYou won!");
                    Console.WriteLine("Press ENTER to restart the game.");
                    //Console.ReadLine();
                    //RestartGame();
                    var continueKey = Console.ReadKey(true);
                    if (continueKey.Key == ConsoleKey.Enter)
                    {
                        RestartGame();
                    }
                    else
                    {
                        Console.WriteLine("OKAY!!!Press any key you like~");
                        Console.ReadKey();
                        RestartGame();
                    }
                    //Console.ReadLine();
                }
            }
        }
        public static void RestartGame()
        {
            Console.Clear();
            wrongTry = 0;
            won = false;
            letterNum = 0;
            Random ram = new Random();
            int randomNumber = ram.Next(1, wordlist.Keys.Count); //获取长度
            rightword = wordlist[randomNumber];
            //rightword = "black";
            wordToGuess = new char[rightword.Length];
            DrawShelf();
            for (int i = 0; i < wordToGuess.Length; i++)
            {
                wordToGuess[i] = '_';
            }
            while (true)
            {
                for (int i = 0; i < wordToGuess.Length; i++)
                {
                    Console.Write(wordToGuess[i]);
                }
                break;
            }
        }

        public static void WoodenShelf(int positionX, int positionY,string woodenShelfSymbol)
        {
            Console.SetCursorPosition(positionX, positionY);
            Console.WriteLine(woodenShelfSymbol);
        }

        public static void DrawShelf()
        {
            Console.ForegroundColor = ConsoleColor.White;
            WoodenShelf(1, 1, "______");
            WoodenShelf(2, 2, "|");
            WoodenShelf(5, 2, "|");
            WoodenShelf(2, 3, "|");
            WoodenShelf(2, 4, "|");
            WoodenShelf(2, 5, "|");
            WoodenShelf(2, 6, "|");
            WoodenShelf(1, 7, "_|______");
        }

        public static void DrawHangman(int wrongTry)
        {
            switch (wrongTry)
            {
                case 1:
                    WoodenShelf(5, 3, "O");
                    break;
                case 2:
                    WoodenShelf(5, 4, "|");
                    WoodenShelf(5, 5, "|");
                    break;
                case 3:
                    WoodenShelf(4, 4, "\\");
                    break;
                case 4:
                    WoodenShelf(6, 4, "/");
                    break;
                case 5:
                    WoodenShelf(4, 6, "/");
                    break;
                case 6:
                    WoodenShelf(6, 6, "\\");
                    break;
            }

        }

    }
}
